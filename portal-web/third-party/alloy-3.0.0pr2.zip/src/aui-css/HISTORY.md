# AUI CSS

> Documentation and test modifications are not included in this changelog. For more details, see [full commit history](https://github.com/liferay/alloy-ui/commits/master/src/aui-css).

## @VERSION@

No registries yet.

## [3.0.0pr1](https://github.com/liferay/alloy-ui/releases/tag/3.0.0pr1)

* [AUI-1225](https://issues.liferay.com/browse/AUI-1225) Import Bootstrap 3 into a new module and remove Grunt bootstrap task

## [2.5.0](https://github.com/liferay/alloy-ui/releases/tag/2.5.0)