# AUI Menu

> Documentation and test modifications are not included in this changelog. For more details, see [full commit history](https://github.com/liferay/alloy-ui/commits/master/src/aui-menu).

## @VERSION@

* [AUI-1526](https://issues.liferay.com/browse/AUI-1526) Create a menu module
