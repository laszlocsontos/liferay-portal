# AUI Live Search Deprecated

> Documentation and test modifications are not included in this changelog. For more details, see [full commit history](https://github.com/liferay/alloy-ui/commits/master/src/aui-live-search).

## @VERSION@

* [AUI-1817](https://issues.liferay.com/browse/AUI-1817) The search box in pagination displays an extra empty white box
