aui-toggler
===========

@VERSION@
------

	* #AUI-938 Fixed issue with TogglerDelegate collapsing direct ancestors on structures with nested togglers
	* #AUI-939 Addressed missing destructors in Toggler and TogglerDelegate